from distutils.core import setup

setup(
      name = 'Food_Finder',
      version = '1.0',
      py_modules = ['Food_Finder']
      )